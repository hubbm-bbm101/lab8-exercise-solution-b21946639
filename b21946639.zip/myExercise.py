import sys


def write(a):
    output_file = open("output.txt", "a")
    output_file.write(a)
    output_file.close()


output = open("output.txt", "w")
output.write("")

file_name = sys.argv[1]
people_str = sys.argv[2]

with open(file_name, "r") as student_file:
    student_str = student_file.read().rstrip()
    student_dict = {}
    student_list = student_str.split("\n")
    for m in student_list:
        m = m.split(":")
        student_dict[m[0]] = m[1]
    student_file.close()

people_list = people_str.split(",")

for m in people_list:
    try:
        write(" Name: " + m + ", University: " + str(student_dict[m]))
    except KeyError:
        write(" No record of '" + m + "' was found!")
